﻿using System;
using System.Collections.Generic;                       //выровнять столбик с байтами
using System.ComponentModel;                               // переименовать переменные
using System.Data;                                             // написать комментарии к функциям
using System.Drawing;                                               //3 ПУНКТ + красивое перемещение
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace os2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            textBox3.Text = "Укажите путь к файлу и дважды щелкните мышкой.";
        }
        
        private void timer1_Tick(object sender, EventArgs e)
        {
            DriveInfo[] allDrives = DriveInfo.GetDrives();

            foreach (DriveInfo d in allDrives)
            //DriveInfo(String) Предоставляет доступ к сведениям на указанном диске.
            {
                textBox1.Text = Convert.ToString("Drive" + d.Name);
                textBox1.Text += Convert.ToString("\r\nDrive type: " + d.DriveType);

                //DriveType Возвращает тип диска, например компакт-диск, съемный, сетевой или несъемный.

                if (d.IsReady == true)
                    //IsReady Возвращает значение, указывающее, готов ли диск.
                {
                    textBox1.Text += Convert.ToString("\r\nVolume label: " + d.VolumeLabel);
                    textBox1.Text += Convert.ToString("\r\nFile system: " + d.DriveFormat);
                    textBox1.Text += Convert.ToString("\r\nAvailable space to current user:         " + d.AvailableFreeSpace + " bytes");
                    textBox1.Text += Convert.ToString("\r\nTotal available space:          " + d.TotalFreeSpace + " bytes");
                    textBox1.Text += Convert.ToString("\r\nTotal size of drive:            " + d.TotalSize + " bytes");

                } 
                
                
                //--------------------------------------------------------------------------------------------------------------------------------------------------------


                string path = @"C:\Users\Lenovo\Desktop\std\2к4сем\ос\2\testfile.txt";
                string path2 = @"C:\Users\Lenovo\Desktop\std\2к4сем\ос\2\testp\testfile.txt";
                try
                {
                    if (!File.Exists(path))
                    {
                        // This statement ensures that the file is created,
                        // but the handle is not kept.
                        using (FileStream fs = File.Create(path)) { }
                    }

                    // Ensure that the target does not exist.
                    if (File.Exists(path2))
                        File.Delete(path2);

                    File.Move(path, path2);
                    textBox2.Text += Convert.ToString(path + " was moved to " + path2);

                    string filePath = "C:/Users/Lenovo/Desktop/std/2к4сем/ос/2/testname.txt";
                    string newName = "newname.txt";
                    FileInfo file = new FileInfo(filePath);
                    file.MoveTo(file.Directory.FullName + "\\" + newName);

                    // See if the original exists now.
                    if (File.Exists(path))
                    {
                        textBox2.Text += Convert.ToString("\r\nThe original file still exists, which is unexpected.");
                    }
                    else
                    {
                        textBox2.Text += Convert.ToString("\r\nThe original file no longer exists, which is expected.");
                    }
                }
                catch (Exception e1)
                {
                    textBox2.Text += Convert.ToString("\r\nThe process failed: " + e1.ToString());
                }

            }
        }

        //--------------------------------------------------------------------------------------------------------------------------------------------------------

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_DoubleClick(object sender, EventArgs e)
        {
            string path3 = textBox3.Text;
            textBox3.Text = "Укажите путь к папке, куда вы хотите переместить объект и нажмите Start!.";
        }

        private void label1_Click_1(object sender, EventArgs e)
        {
            label1.Text = "1.1. Вывод информации о дисках (о наличии, объеме оперативки, свободного места;\n1.2. Вывод on timer (доп).";
        }

        private void label2_Click_1(object sender, EventArgs e)
        {
            label2.Text = "2. Копирование, перемещение, переименование файлов и папок.";
        }
    }
}

